package com.bulbul.thymleafcore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymleafCoreApplication {

	public static void main(String[] args) {
		// fresh start
		SpringApplication.run(ThymleafCoreApplication.class, args);
	}

}
