$(function() {

	'use strict'
	/*
		$('#example').DataTable({
			"processing": true,
			"serverSide": true,
			"ajax": {
				"url": "/pages/userList",
				"type": "POST",
				"dataType": "json",
				"contentType": "application/json",
				"data": function(d) {
					return JSON.stringify(d);
				}
			},
			"columns": [
				{ "data": "name", "width": "20%" },
				{ "data": "position", "width": "20%" },
				{ "data": "office", "width": "20%" },
				{ "data": "start_date", "width": "20%" },
				{ "data": "salary", "width": "20%" }
			]
		});
		
	

	function createToast() {
		$(this).Toasts('create', {
			title: 'Toast Title',
			body: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
		})

	}
		*/
})