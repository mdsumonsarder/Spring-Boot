package app.enums;

public enum WareTransactionType {

    IMPORT,

    EXPORT;
}
