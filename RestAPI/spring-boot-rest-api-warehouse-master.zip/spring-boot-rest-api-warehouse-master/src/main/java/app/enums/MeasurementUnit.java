package app.enums;

public enum MeasurementUnit {

    KG;
}
